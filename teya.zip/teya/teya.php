<?php
session_start();

include 'connect.php';

if (!isset($_SESSION['logged']) || $_SESSION['logged'] != "logged") {
  header("Location: login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Olympians History & Timeline</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom CSS -->
  <style>
    /* Olympic Colors */
    :root {
      --olympic-blue: #0081C8;
      --olympic-yellow: #FFC200;
      --olympic-black: #000000;
      --olympic-green: #00A651;
      --olympic-red: #EE334E;
    }

    /* Hero Section */
    .hero-section {
      background: linear-gradient(to right, var(--olympic-blue), var(--olympic-green), var(--olympic-yellow), var(--olympic-red));
      color: white;
      padding: 150px 0;
      text-align: center;
    }

    /* Navigation Bar */
    .navbar {
      background-color: var(--olympic-black) !important;
    }

    .navbar-brand, .nav-link {
      color: white !important;
    }

    .nav-link:hover {
      color: var(--olympic-yellow) !important;
    }


    /* Timeline Section */
    .timeline-section {
      padding: 80px 0;
    }

    .timeline {
      position: relative;
      max-width: 800px;
      margin: 0 auto;
    }

    .timeline::before {
      content: '';
      position: absolute;
      top: 0;
      bottom: 0;
      width: 4px;
      background-color: var(--olympic-blue);
      left: 50%;
      margin-left: -2px;
    }

    .timeline-item {
      padding: 20px 40px;
      position: relative;
      width: 50%;
    }

    .timeline-item.left {
      left: 0;
    }

    .timeline-item.right {
      left: 50%;
    }

    .timeline-item::after {
      content: '';
      position: absolute;
      width: 20px;
      height: 20px;
      background-color: var(--olympic-red);
      border: 4px solid var(--olympic-yellow);
      top: 20px;
      border-radius: 50%;
      z-index: 1;
    }

    .timeline-item.left::after {
      right: -10px;
    }

    .timeline-item.right::after {
      left: -10px;
    }

    .timeline-content {
      background-color: #f8f9fa;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .timeline-content h3 {
      color: var(--olympic-blue);
    }

    /* Responsive Timeline */
    @media (max-width: 768px) {
      .timeline::before {
        left: 20px; /* Move the line to the left */
      }

      .timeline-item {
        width: 100%;
        padding-left: 70px; /* Add space for the marker */
        padding-right: 20px;
      }

      .timeline-item.left, .timeline-item.right {
        left: 0; /* Align all items to the left */
      }

      .timeline-item::after {
        left: 10px; /* Position the marker on the left */
      }
    }

    /* Featured Olympians Section */
    .featured-olympians {
      padding: 80px 0;
      background-color: #f8f9fa;
    }

    .featured-olympians .card {
      border: none;
      transition: transform 0.3s;
    }

    .featured-olympians .card:hover {
      transform: translateY(-10px);
    }

    .featured-olympians .card-title {
      color: var(--olympic-blue);
    }

    .featured-olympians .btn-primary {
      background-color: var(--olympic-red);
      border: none;
    }

    .featured-olympians .btn-primary:hover {
      background-color: var(--olympic-green);
    }

    /* Olympic Games History Section */
    .games-history {
      padding: 80px 0;
    }

    .games-history h2 {
      color: var(--olympic-black);
    }

    /* Gallery Section */
    .gallery-section {
      padding: 80px 0;
      background-color: #f8f9fa;
    }

    .gallery-section img {
      border-radius: 10px;
      transition: transform 0.3s;
    }

    .gallery-section img:hover {
      transform: scale(1.05);
    }

    /* Contact Section */
    .contact-section {
      padding: 80px 0;
    }

    .contact-section .btn-primary {
      background-color: var(--olympic-red);
      border: none;
    }

    .contact-section .btn-primary:hover {
      background-color: var(--olympic-green);
    }

    /* Footer */
    footer {
      background-color: var(--olympic-black);
      color: white;
      padding: 20px 0;
      text-align: center;
    }
  </style>
</head>
<body>

  <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
      <a class="navbar-brand" href="#">Olympians History</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link active" href="#">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#timeline">Timeline</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#featured">Featured</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#history">History</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#gallery">Gallery</a>
          </li>
          <li class="nav-item">
            <form action="logout.php" method="post" onsubmit="return confirm('Are you sure you want to log out?');">
              <button type="submit" class="btn">Logout</button>
            </form>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Hero Section -->
  <section class="hero-section">
    <div class="container">
      <h1 class="display-4">Olympians History & Timeline</h1>
      <p class="lead">Explore the journey of legendary Olympians through history.</p>
    </div>
  </section>

   <!-- Timeline Section -->
   <section id="timeline" class="timeline-section">
    <div class="container">
      <h2 class="text-center mb-5">Olympians Timeline</h2>
      <div class="timeline">
        <!-- Timeline Item 1 -->
        <div class="timeline-item left">
          <div class="timeline-content">
            <h3>1896: The First Modern Olympics</h3>
            <p>The first modern Olympic Games were held in Athens, Greece. Athletes from 14 nations competed in 43 events.</p>
          </div>
        </div>
        <!-- Timeline Item 2 -->
        <div class="timeline-item right">
          <div class="timeline-content">
            <h3>1936: Jesse Owens Dominates</h3>
            <p>Jesse Owens won four gold medals in track and field at the Berlin Olympics, defying Nazi propaganda.</p>
          </div>
        </div>
        <!-- Timeline Item 3 -->
        <div class="timeline-item left">
          <div class="timeline-content">
            <h3>1960: Wilma Rudolph's Triumph</h3>
            <p>Wilma Rudolph, a former polio patient, won three gold medals in sprint events at the Rome Olympics.</p>
          </div>
        </div>
        <!-- Timeline Item 4 -->
        <div class="timeline-item right">
          <div class="timeline-content">
            <h3>1980: Miracle on Ice</h3>
            <p>The U.S. ice hockey team defeated the Soviet Union in a historic upset at the Lake Placid Winter Olympics.</p>
          </div>
        </div>
        <!-- Timeline Item 5 -->
        <div class="timeline-item left">
          <div class="timeline-content">
            <h3>2008: Michael Phelps' Record</h3>
            <p>Michael Phelps won eight gold medals at the Beijing Olympics, the most by any athlete in a single Games.</p>
          </div>
        </div>
        <!-- Timeline Item 6 -->
        <div class="timeline-item right">
          <div class="timeline-content">
            <h3>2021: Simone Biles' Courage</h3>
            <p>Simone Biles prioritized mental health and inspired the world by withdrawing from events at the Tokyo Olympics.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Featured Olympians Section -->
  <section id="featured" class="featured-olympians">
    <div class="container">
      <h2 class="text-center mb-5">Featured Olympians</h2>
      <div class="row">
        <!-- Olympian 1 -->
        <div class="col-md-4">
          <div class="card">
            <img src="assets/oly1.jpg" class="card-img-top" alt="Jesse Owens">
            <div class="card-body">
              <h5 class="card-title">Jesse Owens</h5>
              <p class="card-text">Four-time gold medalist at the 1936 Berlin Olympics.</p>
              <a href="#" class="btn btn-primary">Learn More</a>
            </div>
          </div>
        </div>
        <!-- Olympian 2 -->
        <div class="col-md-4">
          <div class="card">
            <img src="assets/oly2.jpg" class="card-img-top" alt="Simone Biles">
            <div class="card-body">
              <h5 class="card-title">Simone Biles</h5>
              <p class="card-text">Most decorated American gymnast with 32 Olympic and World Championship medals.</p>
              <a href="#" class="btn btn-primary">Learn More</a>
            </div>
          </div>
        </div>
        <!-- Olympian 3 -->
        <div class="col-md-4">
          <div class="card">
            <img src="assets/oly3.jpg" class="card-img-top" alt="Usain Bolt">
            <div class="card-body">
              <h5 class="card-title">Usain Bolt</h5>
              <p class="card-text">Eight-time Olympic gold medalist and world record holder in sprinting.</p>
              <a href="#" class="btn btn-primary">Learn More</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Olympic Games History Section -->
  <section id="history" class="games-history">
    <div class="container">
      <h2 class="text-center mb-5">Olympic Games History</h2>
      <div class="row">
        <div class="col-md-6">
          <p>The modern Olympic Games were revived in 1896 by Pierre de Coubertin. Since then, the Games have grown into a global event, featuring thousands of athletes from over 200 nations. The Olympics have been held in cities around the world, showcasing the best of human athleticism and spirit.</p>
        </div>
        <div class="col-md-6">
          <img src="assets/histo.jpg" class="img-fluid" alt="Olympic Games History">
        </div>
      </div>
    </div>
  </section>

  <!-- Gallery Section -->
  <section id="gallery" class="gallery-section">
    <div class="container">
      <h2 class="text-center mb-5">Iconic Olympic Moments</h2>
      <div class="row">
        <div class="col-md-4 mb-4">
          <img src="assets/Gal1.jpg" class="img-fluid" alt="Gallery Image 1">
        </div>
        <div class="col-md-4 mb-4">
          <img src="assets/Gal2.jpg" class="img-fluid" alt="Gallery Image 2">
        </div>
        <div class="col-md-4 mb-4">
          <img src="assets/Gal3.jpg" class="img-fluid" alt="Gallery Image 3">
        </div>
      </div>
    </div>
  </section>

  <!-- Contact Section -->
  <section id="contact" class="contact-section">
    <div class="container">
      <h2 class="text-center mb-5">Contact Us</h2>
      <form>
        <div class="mb-3">
          <label for="name" class="form-label">Name</label>
          <input type="text" class="form-control" id="name" placeholder="Enter your name">
        </div>
        <div class="mb-3">
          <label for="email" class="form-label">Email</label>
          <input type="email" class="form-control" id="email" placeholder="Enter your email">
        </div>
        <div class="mb-3">
          <label for="message" class="form-label">Message</label>
          <textarea class="form-control" id="message" rows="5" placeholder="Enter your message"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </section>

  <!-- Footer -->
  <footer>
    <div class="container">
      <p>&copy; 2025 Olympians History. All rights reserved.</p>
    </div>
  </footer>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>